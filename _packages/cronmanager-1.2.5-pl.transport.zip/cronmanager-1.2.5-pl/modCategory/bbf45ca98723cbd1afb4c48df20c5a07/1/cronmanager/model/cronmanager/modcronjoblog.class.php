<?php
class modCronjobLog extends xPDOSimpleObject {}