<?php
class modCronjob extends xPDOSimpleObject {}