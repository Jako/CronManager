<?php
/**
 * The setting lexicon topics for the CronManager
 *
 * @package cronmanager
 * @subpackage lexicon
 */
$_lang['setting_cronmanager.cronjob_id'] = 'Cronjobb-ID';
$_lang['setting_cronmanager.cronjob_id_desc'] = 'Streng som må legges til cronjobb-nettadresse som cronjob_id-parameter.';
$_lang['setting_cronmanager.debug'] = 'Avlus';
$_lang['setting_cronmanager.debug_desc'] = 'Loggfør feilsporingsinfo i MODX-feil-loggen.';
