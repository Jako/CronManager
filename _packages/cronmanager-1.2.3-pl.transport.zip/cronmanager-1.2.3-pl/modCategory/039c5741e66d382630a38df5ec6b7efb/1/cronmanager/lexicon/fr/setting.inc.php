<?php
/**
 * The setting lexicon topics for the CronManager
 *
 * @package cronmanager
 * @subpackage lexicon
 */
$_lang['setting_cronmanager.cronjob_id'] = 'ID Cronjob';
$_lang['setting_cronmanager.cronjob_id_desc'] = 'Chaîne, qui doit être ajoutée à l\'url de cronjob comme paramètre cronjob_id.';
$_lang['setting_cronmanager.debug'] = 'Débogage';
$_lang['setting_cronmanager.debug_desc'] = 'Enregistrer les informations de débogage dans le journal des erreurs du MODX.';
